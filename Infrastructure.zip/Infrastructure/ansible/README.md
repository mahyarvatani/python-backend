# Ansible: Create two kind clusters (hot & standby) on Docker Desktop (WSL Ubuntu)

This playbook installs **kubectl**, **kind**, **helm** (if missing), generates the cluster configs, and creates two clusters:
- `hot`
- `standby`

## Run
```bash
ansible-galaxy collection install -r requirements.yml
```
```bash
ansible-playbook create-kind.yml
```
After creation, install ingress-nginx:
```bash
ansible-playbook install-ingress.yml
```
Clean up:
```bash
ansible-playbook destroy-kind.yml
```

